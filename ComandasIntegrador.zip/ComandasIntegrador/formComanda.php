<?php
    require_once "helpers/Formulario.php";
    require_once "comuns/cabecalho.php";
    require_once "library/Database.php";
    require_once "library/Funcoes.php";

    $db = new Database();
    $dados = [];


    $aMesa = $db->dbSelect("SELECT * FROM mesas ORDER BY ID_MESA");
    
    if ($_GET['acao'] != "insert") {

        $dados = $db->dbSelect("SELECT * FROM comanda WHERE ID_COMANDA = ?", 'first', [$_GET['id']]);
    }

?>
    <main class="container mt-5">
        <div class="row">
            <div class="col-10">
                <h2>Comandas<?= subTitulo($_GET['acao']) ?></h2>
            </div>
            <div class="col-2 text-end">
                <a href="index.php" class="btn btn-outline-secondary btn-sm" title="Voltar">Voltar</a>
            </div>
        </div>

        <form class="g-3" action="<?= $_GET['acao'] ?>index.php" method="post" enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?= isset($dados->ID_COMANDA) ? $dados->ID_PRODUTOS : "" ?>">

            <div class="row">
                <div class="col-12">
                    <label for="nome_cliente" class="form-label">Nome do Cliente</label>
                    <input type="text" class="form-control" name="nome_cliente" 
                        id="nome_cliente" placeholder="Nome do Cliente" maxlength="50"
                        value="<?= isset($dados->DESCRICAO_COMANDA) ? $dados->DESCRICAO_COMANDA : "" ?>">

                </div>
                <div class="col-6">
                    <label for="SITUACAO_COMANDA" class="form-label">Status</label>
                    <select name="SITUACAO_COMANDA" id="SITUACAO_COMANDA" class="form-control" required>
                        <option value=""  <?= isset($aMesa->ID_MESA) ? ($aMesa->ID_MESA == "" ? "selected" : "") : "" ?>>...</option>
                        <?php foreach ($aMesa as $MESA): ?>
                            <option <?= (isset($aMesa->ID_MESA) ? ($aMesa->ID_MESA == $MESA['id'] ? 'selected' : '') : "") ?> 
                            value="<?= $MESA['id'] ?>"><?= $MESA['sigla'] . ' - ' .  $MESA['descricao'] ?></option>
                        <?php endforeach; ?>




                    </select>
                </div>

                
            </div>

        </form>
    </main>
    <script>
        let mesas = document.getElementById('mesa');
    </script>