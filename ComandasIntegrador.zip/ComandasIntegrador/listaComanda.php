<?php
    require_once "comuns/cabecalho.php";
?>

<?php
    require_once "comuns/rodape.php";
?>